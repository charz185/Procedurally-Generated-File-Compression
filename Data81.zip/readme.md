Data81 is the comrpessed version of DataRand.txt
as seen in the file sizes, Data81 is smaller than the other compressed file, "DataRand.7z"